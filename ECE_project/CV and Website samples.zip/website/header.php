<!-- Header content -->

<nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="border-top: 5px solid #e56038;">
<div class="container-fluid">


<div class="navbar-header">

<p class="navbar-text navbar-left" style="font-family: Bradley Hand ITC; font-weight:bolder; font-size:24px">ECE Library</p>
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
</div>

<!-- Collect the nav links, forms, and other content for toggling -->
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

<ul class="nav navbar-nav navbar-right">
<li class="active"><a href="index.php">HOME</a></li>
<li><a href="about.php">ABOUT</a></li>
<li><a href="books.php">BOOKS</a></li>
<li><a href="contact.php">CONTACT</a></li>
</ul>
</div><!-- /.navbar-collapse -->

  </div>
</nav>











