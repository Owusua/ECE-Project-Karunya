<!-- Footer contents-->

<footer>
        <div class="container" style="width: 100%; background-color:#CCC;">
            <div class="row" style="padding-top: 20px">
                <div class="col-md-6 col-md-offset-3 text-center">
                    <ul class="list-inline">
                        <li><a href="http://fb.me/karunyauniversity"><i class="fa fa-facebook fa-3x"></a></i>
                        </li>
                        <li><a href="http://twitter.com/karunyauniv"><i class="fa fa-twitter fa-3x"></a></i>
                        </li>
                        </li>
                    </ul>
                    <hr>
                    <p> &copy; Copyright 2014 by ece.karunya.edu</p>
                </div>
            </div>
        </div>
    </footer>
