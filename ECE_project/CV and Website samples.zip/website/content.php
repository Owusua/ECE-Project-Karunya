<!-- Content page-->
<div class="content_page">

  <div class="row" style="background-color:#FFF; width: 960px; padding: 0 10px; margin: 15px auto; border-radius: 10px;">
       <h2 style="margin: 15px auto; padding: 20px 30px 0px; font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif">Library           Info
       </h2>
      <div class="col-lg-4">
           <p style="margin-top: 20px"><img src="img/item1.png" style="padding-left: 80px; padding-right: 7px" />
                   <strong>Ask the Librarian</strong>
           </p>

           <p style="padding-left:80px; padding-right: 60px">Ask the Libraian any questions concering the library, chat with                Librarian to know which books are current in the library.<a href="about.php">Read more...</a></p>
      </div>
      <div class="col-lg-4">
           <p style="margin-top: 20px"><img src="img/item2.png" style="padding-left: 80px; padding-right: 7px" />
                         <strong>New Trends </strong>
           </p>

           <p style="padding-left:80px; padding-right: 60px">Mordern technology books available in the library to enhance                    research work.<a href="about.php">Read more...</a>
           </p>
      </div>
      <div class="col-lg-4">
           <p style="margin-top: 20px"><img src="img/item3.png" style="padding-left: 80px; padding-right: 7px" />
                 <strong>Open Hours</strong>
           </p>
           <p style="padding-left:80px; padding-right: 60px">The library is open to staff and students from Monday to Friday                     btween the early hours of..<a href="about.php">Read more...</a>
           </p>
      </div>
   </div>

   <div class="row" style="width: 100%">
       <h2 style="margin: 15px auto; padding: 20px 60px; font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif">New Arrivals
       </h2>
       <div class="col-lg-3">
               <div class="row">
                    <div style="padding-left: 90px"><img src="img/51N31MA34EL.jpg" /></div>
                    <div>
                        <p style="padding-left: 90px; padding-top: 10px"><span style="color: #06F; font-weight:bold">AuthorName:
                         </span> Rafael C. Gonzalez, Richard E. Woods
                        </p>
                    </div>
               </div>
       </div>
       <div class="col-lg-3">
               <div class="row">
                     <div style="padding-left: 90px"><img src="img/original1.595397.2.jpg" /></div>
                     <div>
                         <p style="padding-left: 90px; padding-top: 10px"><span style="color: #06F; font-weight:bold">                             AuthorName:</span> Rajaraman V.
                         </p>
                     </div>
               </div>
       </div>
       <div class="col-lg-3">
              <div class="row">
                     <div style="padding-left: 90px"><img src="img/5129TM9HAFL.jpg" /></div>
                     <div>
                          <p style="padding-left: 90px; padding-top: 10px"><span style="color: #06F; font-weight:bold">                             AuthorName:</span> Grob Bernard</p>
                     </div>
             </div>
       </div>
       <div class="col-lg-3">
              <div class="row">
                     <div style="padding-left: 90px"><img src="img/41LoheQsXAL.jpg" /></div>
                     <div>
                          <p style="padding-left: 90px; padding-top: 10px"><span style="color: #06F; font-weight:bold">                              AuthorName:</span> Brij N Agrawal
                          </p>
                     </div>
             </div>
       </div>
   </div>

</div>
